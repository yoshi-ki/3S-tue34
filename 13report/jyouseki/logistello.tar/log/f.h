// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

extern void (*finit[100*4*2*11+1])(void);
