// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

#ifndef FASTEND_H
#define FASTEND_H

#include "move.h"

int FastEnd(
  ZUGIO		*pzio,	
  PARTEI	player,	
  int		al,
  int		be
);

#endif
