// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

/* generate example positions labelled with pass-value:
 *
 *     1 <=> unexpected last side to move
 */

#include "main.h"
#include "lib.h"
#include "sboard.h"
#include "crt.h"
#include "goodies.h"
#include "game.h"
#include "tab.h"
#include "patt.h"

