// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

#ifndef O_MERKST
#define O_MERKST

#include "featurem.h"
#include "board.h"




MERKMAL_B STABDIFF_B, STABB_B, STABW_B, STABRI_B, SEMIDIFF_B;

MERKMAL   STABDIFF, STABB, STABW, STABRI, SEMIDIFF;

extern bool f_stabneu;

#endif
