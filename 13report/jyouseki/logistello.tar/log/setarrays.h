// (c) Michael Buro 1992-2002, licensed under the GNU Public License, version 2

#include "main.h"

extern uint1 Set8B[],Set7B[],Set6B[],Set5B[],Set4B[],Set3B[];
extern uint1 Set8W[],Set7W[],Set6W[],Set5W[],Set4W[],Set3W[];

